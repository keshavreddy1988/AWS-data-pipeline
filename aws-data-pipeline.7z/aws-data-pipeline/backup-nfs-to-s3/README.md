# Backup an EFS to S3

Use s3 lifecycle events to setup a retention policy
