# Restore an S3 bucket/key to NFS

The restore doesn't sync the remote bucket with the EFS. It just copy files from
S3 to the destination

